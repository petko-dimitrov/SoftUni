let Person = require('./person.js');

result.Person = Person;